# Hello-World
My First Respository
## This is a Markdown File
Singing is my favorite hobby.
I'm a nerd and super goofy.
I'm a dog mom with 3 kiddos as well!
I refuse to quit or give up on anything